// Theme switching functionality with enhanced transitions

document.addEventListener('DOMContentLoaded', function() {
    const themeToggle = document.getElementById('themeToggle');
    const htmlElement = document.documentElement;
    const body = document.body;
    
    // Add transition class to body for smooth theme changes
    body.classList.add('theme-transition');
    
    // Check if user has a saved preference
    const savedTheme = localStorage.getItem('olympicsAppTheme');
    
    // Initialize with saved theme or default to dark
    if (savedTheme) {
        htmlElement.setAttribute('data-bs-theme', savedTheme);
        themeToggle.checked = (savedTheme === 'light');
    }
    
    // Toggle theme when switch is clicked
    themeToggle.addEventListener('change', function() {
        const newTheme = this.checked ? 'light' : 'dark';
        
        // Apply transition
        body.style.transition = 'background-color 0.5s ease, color 0.5s ease';
        
        // Update theme
        htmlElement.setAttribute('data-bs-theme', newTheme);
        localStorage.setItem('olympicsAppTheme', newTheme);
        
        // Update Plotly charts with slight delay to ensure smooth transition
        setTimeout(() => {
            updatePlotlyCharts(newTheme);
        }, 100);
        
        // Add animation to toggle switch
        const toggleWrapper = document.querySelector('.theme-toggle-wrapper');
        toggleWrapper.classList.add('theme-toggle-animated');
        setTimeout(() => {
            toggleWrapper.classList.remove('theme-toggle-animated');
        }, 600);
    });
    
    // Function to update Plotly charts when theme changes
    function updatePlotlyCharts(theme) {
        // Get all chart containers
        const chartContainers = document.querySelectorAll('.chart-container');
        
        // Only proceed if we have charts and Plotly is loaded
        if (chartContainers.length > 0 && window.Plotly) {
            try {
                // Update template for each chart
                chartContainers.forEach(container => {
                    const plotlyDiv = container.firstElementChild;
                    if (plotlyDiv && plotlyDiv._fullLayout) {
                        const template = theme === 'light' ? 'plotly' : 'plotly_dark';
                        
                        // Define colors based on theme
                        const bgColor = theme === 'light' ? '#ffffff' : 'transparent';
                        const gridColor = theme === 'light' ? '#eee' : '#333';
                        const textColor = theme === 'light' ? '#2c3e50' : '#ffffff';
                        
                        // Apply the theme
                        Plotly.relayout(plotlyDiv, {
                            template: template,
                            paper_bgcolor: bgColor,
                            plot_bgcolor: bgColor,
                            font: { color: textColor }
                        });
                    }
                });
            } catch (error) {
                console.warn('Error updating Plotly charts:', error);
            }
        }
    }
    
    // Add required CSS for theme transition animation
    const style = document.createElement('style');
    style.textContent = `
        .theme-transition * {
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
        }
        
        .theme-toggle-animated {
            animation: pulse 0.6s ease;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
    `;
    document.head.appendChild(style);
});