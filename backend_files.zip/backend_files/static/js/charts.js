// Charts.js for Olympics Data Visualization

// Global Plotly configuration
const config = {
    responsive: true,
    displayModeBar: true,
    displaylogo: false,
    modeBarButtonsToRemove: ['lasso2d', 'select2d']
};

// Olympic colors
const olympicColors = {
    blue: '#0085C7',
    yellow: '#F4C300',
    black: '#000000',
    green: '#009F3D',
    red: '#DF0024'
};

// Error handling function
function handleError(element, message) {
    element.innerHTML = `
        <div class="alert alert-danger" role="alert">
            <h4 class="alert-heading">Error Loading Data</h4>
            <p>${message}</p>
            <hr>
            <p class="mb-0">Please try refreshing the page or contact support if the issue persists.</p>
        </div>
    `;
}

// Loading indicator
function showLoading(element) {
    element.innerHTML = `
        <div class="chart-loading">
            <div class="spinner-border text-light" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;
}

// Medal Trends Chart
function createMedalTrendsChart() {
    const chartElement = document.getElementById('medalTrendsChart');
    if (!chartElement) return;
    
    showLoading(chartElement);
    
    fetch('./static/data/medal-trends.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Sort data by year
            data.sort((a, b) => a.year - b.year);
            
            const years = data.map(entry => entry.year);
            const goldMedals = data.map(entry => entry.gold);
            const silverMedals = data.map(entry => entry.silver);
            const bronzeMedals = data.map(entry => entry.bronze);
            
            const traces = [
                {
                    x: years,
                    y: goldMedals,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'Gold',
                    line: {
                        color: olympicColors.yellow,
                        width: 3
                    },
                    marker: {
                        size: 8,
                        color: olympicColors.yellow
                    }
                },
                {
                    x: years,
                    y: silverMedals,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'Silver',
                    line: {
                        color: '#C0C0C0',
                        width: 3
                    },
                    marker: {
                        size: 8,
                        color: '#C0C0C0'
                    }
                },
                {
                    x: years,
                    y: bronzeMedals,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'Bronze',
                    line: {
                        color: '#CD7F32',
                        width: 3
                    },
                    marker: {
                        size: 8,
                        color: '#CD7F32'
                    }
                }
            ];
            
            const layout = {
                title: 'Olympic Medal Trends Over Time',
                xaxis: {
                    title: 'Olympic Year',
                    tickmode: 'array',
                    tickvals: years.filter((_, i) => i % 4 === 0), // Show every 4th year
                    tickangle: -45
                },
                yaxis: {
                    title: 'Number of Medals'
                },
                legend: {
                    x: 0.1,
                    y: 1.1,
                    orientation: 'h'
                },
                template: 'plotly_dark',
                font: {
                    family: 'Arial, sans-serif'
                },
                margin: {
                    l: 60,
                    r: 30,
                    b: 80,
                    t: 80,
                    pad: 5
                }
            };
            
            Plotly.newPlot(chartElement, traces, layout, config);
        })
        .catch(error => {
            console.error('Error fetching medal trends data:', error);
            handleError(chartElement, 'Failed to load medal trends data.');
        });
}

// Host Nation Advantage Chart
function createHostAdvantageChart() {
    const chartElement = document.getElementById('hostAdvantageChart');
    if (!chartElement) return;
    
    showLoading(chartElement);
    
    fetch('./static/data/host-advantage.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Sort data by year
            data.sort((a, b) => a.year - b.year);
            
            const years = data.map(entry => entry.year);
            const countries = data.map(entry => entry.country);
            const labelsWithYear = data.map(entry => `${entry.country} (${entry.year})`);
            const medalsAsHost = data.map(entry => entry.medals_as_host);
            const avgMedalsNonHost = data.map(entry => entry.avg_medals_non_host);
            
            const traces = [
                {
                    x: labelsWithYear,
                    y: medalsAsHost,
                    type: 'bar',
                    name: 'Medals as Host',
                    marker: {
                        color: olympicColors.blue
                    },
                    hovertemplate: '<b>%{x}</b><br>Medals: %{y}<extra></extra>'
                },
                {
                    x: labelsWithYear,
                    y: avgMedalsNonHost,
                    type: 'bar',
                    name: 'Avg Medals when not Host',
                    marker: {
                        color: olympicColors.green
                    },
                    hovertemplate: '<b>%{x}</b><br>Avg Medals: %{y:.1f}<extra></extra>'
                }
            ];
            
            const layout = {
                title: 'Host Nation Medal Advantage',
                xaxis: {
                    title: 'Host Country (Year)',
                    tickangle: -45
                },
                yaxis: {
                    title: 'Number of Medals'
                },
                barmode: 'group',
                bargap: 0.15,
                bargroupgap: 0.1,
                legend: {
                    x: 0.1,
                    y: 1.1,
                    orientation: 'h'
                },
                template: 'plotly_dark',
                font: {
                    family: 'Arial, sans-serif'
                },
                margin: {
                    l: 60,
                    r: 30,
                    b: 100,
                    t: 80,
                    pad: 5
                }
            };
            
            Plotly.newPlot(chartElement, traces, layout, config);
        })
        .catch(error => {
            console.error('Error fetching host advantage data:', error);
            handleError(chartElement, 'Failed to load host nation advantage data.');
        });
}

// Participation Growth Chart
function createParticipationChart() {
    const chartElement = document.getElementById('participationChart');
    if (!chartElement) return;
    
    showLoading(chartElement);
    
    fetch('./static/data/participation.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Sort data by year
            data.sort((a, b) => a.year - b.year);
            
            const years = data.map(entry => entry.year);
            const totalAthletes = data.map(entry => entry.total_athletes);
            const maleAthletes = data.map(entry => entry.male_athletes);
            const femaleAthletes = data.map(entry => entry.female_athletes);
            
            const traces = [
                {
                    x: years,
                    y: totalAthletes,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'Total Athletes',
                    line: {
                        color: olympicColors.blue,
                        width: 3
                    },
                    marker: {
                        size: 8,
                        color: olympicColors.blue
                    }
                },
                {
                    x: years,
                    y: maleAthletes,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'Male Athletes',
                    line: {
                        color: olympicColors.green,
                        width: 3
                    },
                    marker: {
                        size: 8,
                        color: olympicColors.green
                    }
                },
                {
                    x: years,
                    y: femaleAthletes,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'Female Athletes',
                    line: {
                        color: olympicColors.red,
                        width: 3
                    },
                    marker: {
                        size: 8,
                        color: olympicColors.red
                    }
                }
            ];
            
            const layout = {
                title: 'Growth in Olympic Participation Over Time',
                xaxis: {
                    title: 'Olympic Year',
                    tickmode: 'array',
                    tickvals: years.filter((_, i) => i % 4 === 0), // Show every 4th year
                    tickangle: -45
                },
                yaxis: {
                    title: 'Number of Athletes'
                },
                legend: {
                    x: 0.1,
                    y: 1.1,
                    orientation: 'h'
                },
                template: 'plotly_dark',
                font: {
                    family: 'Arial, sans-serif'
                },
                margin: {
                    l: 70,
                    r: 30,
                    b: 80,
                    t: 80,
                    pad: 5
                }
            };
            
            Plotly.newPlot(chartElement, traces, layout, config);
        })
        .catch(error => {
            console.error('Error fetching participation data:', error);
            handleError(chartElement, 'Failed to load participation growth data.');
        });
}

// Top Countries Chart
function createTopCountriesChart() {
    const chartElement = document.getElementById('topCountriesChart');
    if (!chartElement) return;
    
    showLoading(chartElement);
    
    fetch('./static/data/top-countries.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Sort data by total medals (descending)
            data.sort((a, b) => b.total_medals - a.total_medals);
            
            const countries = data.map(entry => entry.country);
            const goldMedals = data.map(entry => entry.gold);
            const silverMedals = data.map(entry => entry.silver);
            const bronzeMedals = data.map(entry => entry.bronze);
            
            const traces = [
                {
                    x: countries,
                    y: goldMedals,
                    name: 'Gold',
                    type: 'bar',
                    marker: {
                        color: olympicColors.yellow
                    }
                },
                {
                    x: countries,
                    y: silverMedals,
                    name: 'Silver',
                    type: 'bar',
                    marker: {
                        color: '#C0C0C0'
                    }
                },
                {
                    x: countries,
                    y: bronzeMedals,
                    name: 'Bronze',
                    type: 'bar',
                    marker: {
                        color: '#CD7F32'
                    }
                }
            ];
            
            const layout = {
                title: 'Top 10 Countries by Olympic Medal Count',
                xaxis: {
                    title: 'Country',
                    tickangle: -45
                },
                yaxis: {
                    title: 'Number of Medals'
                },
                barmode: 'stack',
                legend: {
                    x: 0.1,
                    y: 1.1,
                    orientation: 'h'
                },
                template: 'plotly_dark',
                font: {
                    family: 'Arial, sans-serif'
                },
                margin: {
                    l: 60,
                    r: 30,
                    b: 100,
                    t: 80,
                    pad: 5
                }
            };
            
            Plotly.newPlot(chartElement, traces, layout, config);
        })
        .catch(error => {
            console.error('Error fetching top countries data:', error);
            handleError(chartElement, 'Failed to load top countries data.');
        });
}

// Initialize charts when the page loads
document.addEventListener('DOMContentLoaded', function() {
    // Check which chart is needed based on the current page
    if (document.getElementById('medalTrendsChart')) {
        createMedalTrendsChart();
    }
    
    if (document.getElementById('hostAdvantageChart')) {
        createHostAdvantageChart();
    }
    
    if (document.getElementById('participationChart')) {
        createParticipationChart();
    }
    
    if (document.getElementById('topCountriesChart')) {
        createTopCountriesChart();
    }
});
