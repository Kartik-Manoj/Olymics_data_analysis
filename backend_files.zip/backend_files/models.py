from app import db

class MedalCount(db.Model):
    """Model for medal counts over time."""
    id = db.Column(db.Integer, primary_key=True)
    year = db.Column(db.Integer, nullable=False)
    gold = db.Column(db.Integer, nullable=False)
    silver = db.Column(db.Integer, nullable=False)
    bronze = db.Column(db.Integer, nullable=False)
    
    def __repr__(self):
        return f"<MedalCount {self.year}>"

class HostAdvantage(db.Model):
    """Model for host nation advantage data."""
    id = db.Column(db.Integer, primary_key=True)
    year = db.Column(db.Integer, nullable=False)
    country = db.Column(db.String(100), nullable=False)
    medals_as_host = db.Column(db.Integer, nullable=False)
    avg_medals_non_host = db.Column(db.Float, nullable=False)
    
    def __repr__(self):
        return f"<HostAdvantage {self.country} {self.year}>"

class Participation(db.Model):
    """Model for participation growth data."""
    id = db.Column(db.Integer, primary_key=True)
    year = db.Column(db.Integer, nullable=False)
    total_athletes = db.Column(db.Integer, nullable=False)
    male_athletes = db.Column(db.Integer, nullable=False)
    female_athletes = db.Column(db.Integer, nullable=False)
    
    def __repr__(self):
        return f"<Participation {self.year}>"

class CountryPerformance(db.Model):
    """Model for country performance data."""
    id = db.Column(db.Integer, primary_key=True)
    country = db.Column(db.String(100), nullable=False)
    gold = db.Column(db.Integer, nullable=False)
    silver = db.Column(db.Integer, nullable=False)
    bronze = db.Column(db.Integer, nullable=False)
    total_medals = db.Column(db.Integer, nullable=False)
    
    def __repr__(self):
        return f"<CountryPerformance {self.country}>"
