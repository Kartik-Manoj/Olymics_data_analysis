import os
import logging
from flask import Flask, render_template, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
# create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1) # needed for url_for to generate with https

# configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# initialize the app with the extension
db.init_app(app)

# Import routes and models after initializing db to avoid circular imports
with app.app_context():
    # Import models
    import models  # noqa: F401
    
    # Import data processor
    from data_processor import init_database, process_data
    
    # Create tables
    db.create_all()
    
    # Initialize database with data if needed
    init_database()

# Import routes
from models import MedalCount, HostAdvantage, Participation, CountryPerformance

@app.route('/')
def index():
    """Render the home page with navigation to other pages."""
    return render_template('index.html')

@app.route('/medal-trends')
def medal_trends():
    """Render the medal trends page."""
    return render_template('medal_trends.html')

@app.route('/host-advantage')
def host_advantage():
    """Render the host nation advantage page."""
    return render_template('host_advantage.html')

@app.route('/participation')
def participation():
    """Render the growth in participation page."""
    return render_template('participation.html')

@app.route('/top-countries')
def top_countries():
    """Render the top performing countries page."""
    return render_template('top_countries.html')

# API routes for fetching data
@app.route('/api/medal-trends')
def api_medal_trends():
    """API endpoint for medal trends data."""
    try:
        medal_data = MedalCount.query.all()
        data = [
            {
                'year': entry.year,
                'gold': entry.gold,
                'silver': entry.silver,
                'bronze': entry.bronze
            } for entry in medal_data
        ]
        return jsonify(data)
    except Exception as e:
        logger.error(f"Error fetching medal trends data: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/host-advantage')
def api_host_advantage():
    """API endpoint for host nation advantage data."""
    try:
        host_data = HostAdvantage.query.all()
        data = [
            {
                'year': entry.year,
                'country': entry.country,
                'medals_as_host': entry.medals_as_host,
                'avg_medals_non_host': entry.avg_medals_non_host
            } for entry in host_data
        ]
        return jsonify(data)
    except Exception as e:
        logger.error(f"Error fetching host advantage data: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/participation')
def api_participation():
    """API endpoint for participation growth data."""
    try:
        participation_data = Participation.query.all()
        data = [
            {
                'year': entry.year,
                'total_athletes': entry.total_athletes,
                'male_athletes': entry.male_athletes,
                'female_athletes': entry.female_athletes
            } for entry in participation_data
        ]
        return jsonify(data)
    except Exception as e:
        logger.error(f"Error fetching participation data: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/top-countries')
def api_top_countries():
    """API endpoint for top performing countries data."""
    try:
        country_data = CountryPerformance.query.order_by(
            CountryPerformance.total_medals.desc()
        ).limit(10).all()
        
        data = [
            {
                'country': entry.country,
                'gold': entry.gold,
                'silver': entry.silver,
                'bronze': entry.bronze,
                'total_medals': entry.total_medals
            } for entry in country_data
        ]
        return jsonify(data)
    except Exception as e:
        logger.error(f"Error fetching top countries data: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
