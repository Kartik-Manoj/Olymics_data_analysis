import os
import logging
import pandas as pd
from sqlalchemy.exc import SQLAlchemyError
from app import db
from models import MedalCount, HostAdvantage, Participation, CountryPerformance

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def init_database():
    """Initialize the database with data if tables are empty."""
    try:
        # Check if data already exists
        if MedalCount.query.first() is None:
            logger.info("Initializing database with sample Olympic data...")
            process_data()
        else:
            logger.info("Database already initialized.")
    except Exception as e:
        logger.error(f"Error initializing database: {e}")

def process_data():
    """Process Olympics data and store in database."""
    try:
        # Read the actual data from the Excel file
        excel_path = 'attached_assets/olympics.xlsx'
        
        # Use pandas to read the Excel file
        logger.info(f"Reading data from Excel file: {excel_path}")
        
        # Read medal count data - use the correct sheet name
        medal_df = pd.read_excel(excel_path, sheet_name='Medal Trends ')
        # Transform data for medal trends
        medal_data = []
        for year in medal_df['Year'].unique():
            year_data = medal_df[medal_df['Year'] == year]
            total_gold = int(year_data['Gold'].sum())
            total_silver = int(year_data['Silver'].sum())
            total_bronze = int(year_data['Bronze'].sum())
            medal_data.append({
                'year': int(year),
                'gold': total_gold,
                'silver': total_silver,
                'bronze': total_bronze
            })
        
        # Read host advantage data
        host_df = pd.read_excel(excel_path, sheet_name='Host Nation Advantage ')
        # Transform data for host advantage
        host_data = []
        for _, row in host_df.iterrows():
            host_data.append({
                'year': int(row['Year']),
                'country': str(row['Host Country']),
                'medals_as_host': int(row['Total Medals']),
                'avg_medals_non_host': float(row['Total Medals'] - row['Gold Medal Difference from Average'])
            })
        
        # Read participation data
        participation_df = pd.read_excel(excel_path, sheet_name='Growth in Participation')
        # Transform data for participation
        participation_data = []
        for _, row in participation_df.iterrows():
            participation_data.append({
                'year': int(row['Year']),
                'total_athletes': int(row['Male Athletes'] + row['Female Athletes']),
                'male_athletes': int(row['Male Athletes']),
                'female_athletes': int(row['Female Athletes'])
            })
        
        # Read top performing countries data - aggregate medal counts by country
        # We'll use the Medal Trends sheet as it contains country medals
        medal_by_country = medal_df.groupby('Country').agg({
            'Gold': 'sum',
            'Silver': 'sum',
            'Bronze': 'sum',
            'Total Medals': 'sum'
        }).reset_index()
        
        # Get top 15 countries by total medals
        country_df = medal_by_country.sort_values('Total Medals', ascending=False).head(15)
        
        # Transform data for country performance
        country_data = []
        for _, row in country_df.iterrows():
            country_data.append({
                'country': str(row['Country']),
                'gold': int(row['Gold']),
                'silver': int(row['Silver']),
                'bronze': int(row['Bronze']),
                'total_medals': int(row['Total Medals'])
            })
        
        logger.info("Successfully processed data from Excel file")
        
        # Insert data into database
        # Medal count data
        for entry in medal_data:
            medal_count = MedalCount(
                year=entry["year"],
                gold=entry["gold"],
                silver=entry["silver"],
                bronze=entry["bronze"]
            )
            db.session.add(medal_count)
        
        # Host advantage data
        for entry in host_data:
            host_advantage = HostAdvantage(
                year=entry["year"],
                country=entry["country"],
                medals_as_host=entry["medals_as_host"],
                avg_medals_non_host=entry["avg_medals_non_host"]
            )
            db.session.add(host_advantage)
        
        # Participation data
        for entry in participation_data:
            participation = Participation(
                year=entry["year"],
                total_athletes=entry["total_athletes"],
                male_athletes=entry["male_athletes"],
                female_athletes=entry["female_athletes"]
            )
            db.session.add(participation)
        
        # Country performance data
        for entry in country_data:
            country_performance = CountryPerformance(
                country=entry["country"],
                gold=entry["gold"],
                silver=entry["silver"],
                bronze=entry["bronze"],
                total_medals=entry["total_medals"]
            )
            db.session.add(country_performance)
        
        # Commit all changes to the database
        db.session.commit()
        logger.info("Successfully added Olympic data to database")
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error processing data: {e}")
        raise

if __name__ == "__main__":
    # This can be used to test the data processor independently
    pass
