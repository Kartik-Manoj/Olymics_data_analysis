# Olympics Data Analysis - Backend Files

This folder contains all the backend files needed to run the Olympics Data Analysis application. The backend is built with Flask and uses a PostgreSQL database.

## Files Overview

- `app.py` - Main Flask application with routes and API endpoints
- `main.py` - Entry point for the application
- `models.py` - Database models (SQLAlchemy)
- `data_processor.py` - Data processing logic for importing Olympic data
- `requirements.txt` - Dependencies for the project
- `data/` - JSON data files exported from the database

## Setup Instructions

1. Make sure you have Python 3.8+ installed.

2. Install the dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Set up environment variables:
   ```
   export DATABASE_URL="postgresql://username:password@localhost:5432/olympics_db"
   export SESSION_SECRET="your-secret-key"
   ```

4. Initialize the database:
   ```
   python data_processor.py
   ```

5. Run the application:
   ```
   python main.py
   ```

   The application will be available at http://localhost:5000

## Database Schema

The application uses the following database models:

1. **MedalCount** - Tracks medal counts over time
   - Year, Gold, Silver, Bronze

2. **HostAdvantage** - Compares host nations' performances
   - Year, Country, Medals as Host, Average Medals when not Host

3. **Participation** - Tracks athlete participation numbers
   - Year, Total Athletes, Male Athletes, Female Athletes

4. **CountryPerformance** - Records country medal performance
   - Country, Gold, Silver, Bronze, Total Medals

## Data Sources

The original data comes from an Excel file (olympics.xlsx) with Olympic Games statistics. The data is processed and stored in the PostgreSQL database by the data_processor.py script.

## API Endpoints

- `/api/medal-trends` - Returns medal count data over time
- `/api/host-advantage` - Returns host nation advantage data
- `/api/participation` - Returns participation growth data
- `/api/top-countries` - Returns top performing countries data

## Static Files

The `data/` directory contains JSON exports of the database tables for use in the static site version.